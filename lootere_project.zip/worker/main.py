import sys
import logging
from worker.celery_app import celery_app

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "beat":
        celery_app.Beat().run()
    else:
        celery_app.worker_main(argv=["worker", "--loglevel=info"])
