from typing import Tuple, List, Dict, Any, Optional
from pyrogram import Client
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from motor.motor_asyncio import AsyncIOMotorDatabase

async def verify_force_join(client: Client, db: AsyncIOMotorDatabase, user_id: int) -> Tuple[bool, List[Dict[str, Any]], Optional[InlineKeyboardMarkup]]:
    channels = await db.channels.find({"force_join_required": True}).to_list(100)
    if not channels:
        return True, [], None

    unjoined = []
    buttons = []
    for ch in channels:
        try:
            member = await client.get_chat_member(ch["channel_id"], user_id)
            if member.status in ["kicked", "left"]:
                unjoined.append(ch)
                buttons.append([InlineKeyboardButton(f"📢 Join {ch.get('title', 'Channel')}", url=ch.get("invite_link"))])
        except Exception:
            unjoined.append(ch)
            buttons.append([InlineKeyboardButton(f"📢 Join {ch.get('title', 'Channel')}", url=ch.get("invite_link"))])

    if unjoined:
        buttons.append([InlineKeyboardButton("🔄 Verify Subscription", callback_data="check_force_join")])
        return False, unjoined, InlineKeyboardMarkup(buttons)

    return True, [], None
